#!/bin/sh
set -eu

if [ "$(id -u)" -ne 0 ]; then
    echo "Run this installer as root." >&2
    exit 1
fi

SRC_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
APP_DIR=/opt/caltopo-history
DATA_DIR=/var/lib/caltopo-history
ENV_FILE=/etc/caltopo-history.env
SERVICE_USER=caltopo-history

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip ca-certificates curl iproute2

if ! getent passwd "$SERVICE_USER" >/dev/null 2>&1; then
    useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"
fi

install -d -o root -g root -m 0755 "$APP_DIR"
install -d -o "$SERVICE_USER" -g "$SERVICE_USER" -m 0700 "$DATA_DIR"

# Keep runtime data and local environment outside the application directory.
rm -rf "$APP_DIR/app" "$APP_DIR/tests" "$APP_DIR/deploy"
cp -a "$SRC_DIR/app" "$APP_DIR/"
cp -a "$SRC_DIR/tests" "$APP_DIR/"
cp -a "$SRC_DIR/deploy" "$APP_DIR/"
install -m 0644 "$SRC_DIR/requirements.txt" "$APP_DIR/requirements.txt"
install -m 0644 "$SRC_DIR/pytest.ini" "$APP_DIR/pytest.ini"

python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip wheel
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"

if [ ! -f "$ENV_FILE" ]; then
    install -o root -g root -m 0600 "$SRC_DIR/deploy/caltopo-history.env.example" "$ENV_FILE"
    echo "Created $ENV_FILE. Edit the CHANGE_ME values before starting the service."
else
    echo "Keeping existing $ENV_FILE unchanged."
fi

install -o root -g root -m 0644 "$SRC_DIR/deploy/caltopo-history.service" /etc/systemd/system/caltopo-history.service
systemctl daemon-reload
systemctl enable caltopo-history.service

if ss -ltn 2>/dev/null | grep -q "127.0.0.1:8765"; then
    echo "WARNING: TCP port 8765 is already in use. Change the port in the systemd unit and ISPConfig proxy directives before starting." >&2
fi

echo
echo "Installation complete."
echo "1. Edit: nano $ENV_FILE"
echo "2. Test config: systemctl start caltopo-history && systemctl status caltopo-history --no-pager"
echo "3. Local health check: curl http://127.0.0.1:8765/healthz"
echo "4. Configure the ISPConfig HTTPS website as reverse proxy to 127.0.0.1:8765."
